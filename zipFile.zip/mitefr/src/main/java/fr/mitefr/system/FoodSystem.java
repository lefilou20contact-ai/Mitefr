package fr.mitefr.system;

import fr.mitefr.MiteFRConstants;
import fr.mitefr.data.Disease;
import fr.mitefr.data.MitePlayerDataHolder;
import fr.mitefr.data.MiteFRGameRules;
import fr.mitefr.data.PlayerMiteData;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Système alimentaire avancé :
 * - Péremption des aliments (3 jours de jeu = 72 000 ticks)
 * - Suivi de la diversité alimentaire (anti-scorbut)
 * - Eau sale = intoxication
 */
public final class FoodSystem {

    /** Durée de vie d'un aliment en ticks (3 jours de jeu) */
    public static final long SPOIL_TICKS = 72_000L;

    /** Clé NBT de l'âge de l'aliment */
    public static final String NBT_AGE = MiteFRConstants.NBT_FOOD_AGE;

    /** Ticks sans fruits/légumes avant scorbut (5 jours) */
    private static final long SCURVY_THRESHOLD = 120_000L;

    /** Clé NBT du compteur anti-scorbut sur le joueur */
    private static final String NBT_SCURVY_TIMER = "mitefr_scurvy_timer";

    private FoodSystem() {}

    // ── Vieillissement des aliments dans l'inventaire ────────────────

    /**
     * Fait vieillir tous les aliments de l'inventaire du joueur.
     * Appelé toutes les 20 ticks depuis le tick serveur principal.
     */
    public static void tickInventoryAging(ServerPlayerEntity player) {
        if (!player.getWorld().getGameRules().getBoolean(MiteFRGameRules.ENABLE_FOOD_SPOILAGE)) return;

        for (int i = 0; i < player.getInventory().size(); i++) {
            ItemStack stack = player.getInventory().getStack(i);
            if (stack.isEmpty() || !stack.getItem().isFood()) continue;

            NbtCompound nbt = stack.getOrCreateNbt();
            long age = nbt.getLong(NBT_AGE);
            nbt.putLong(NBT_AGE, age + 20L);

            if (age >= SPOIL_TICKS && !nbt.getBoolean("mitefr_spoiled")) {
                nbt.putBoolean("mitefr_spoiled", true);
                // Renommer visuellement (CustomName via NbtString)
                stack.setCustomName(
                    Text.literal("[Avarie] ").formatted(Formatting.DARK_RED)
                        .append(stack.getName().copy().formatted(Formatting.GRAY))
                );
                player.sendMessage(
                    Text.literal("⚠ Un aliment dans votre inventaire s'est avarié !")
                        .formatted(Formatting.YELLOW),
                    true
                );
            }
        }
    }

    /**
     * Vérifie si un aliment est avarié.
     */
    public static boolean isSpoiled(ItemStack stack) {
        if (stack.isEmpty() || !stack.hasNbt()) return false;
        return stack.getNbt().getBoolean("mitefr_spoiled");
    }

    /**
     * Marque un item comme fraîchement créé/cuisiné.
     */
    public static void markFresh(ItemStack stack) {
        NbtCompound nbt = stack.getOrCreateNbt();
        nbt.putLong(NBT_AGE, 0L);
        nbt.putBoolean("mitefr_spoiled", false);
    }

    // ── Suivi anti-scorbut ───────────────────────────────────────────

    /**
     * Notifie que le joueur a mangé un aliment contenant de la vitamine C.
     * Réinitialise le compteur de scorbut.
     */
    public static void onAteVitaminFood(ServerPlayerEntity player) {
        NbtCompound data = player.writeNbt(new NbtCompound());
        player.readNbt(data); // accès NBT custom via mixin plus propre, simplifié ici
        PlayerMiteData miteData = ((MitePlayerDataHolder) player).mitefr_getData();
        // Réinitialiser le timer scorbut en guérissant si présent
        if (miteData.hasDisease(Disease.SCORBUT)) {
            miteData.removeDisease(Disease.SCORBUT);
            player.sendMessage(
                Text.literal("✦ Le scorbut régresse grâce à votre alimentation.")
                    .formatted(Formatting.GREEN),
                false
            );
        }
    }

    /**
     * Tick du compteur scorbut (appelé toutes les 200 ticks depuis DiseaseSystem).
     */
    public static void tickScurvyCounter(ServerPlayerEntity player) {
        if (!player.getWorld().getGameRules().getBoolean(MiteFRGameRules.ENABLE_DISEASES)) return;
        PlayerMiteData data = ((MitePlayerDataHolder) player).mitefr_getData();

        // Incrémenter via un champ NBT persistant sur le joueur
        // Pour simplifier, on utilise le PlayerMiteData comme proxy
        // Le vrai compteur serait dans PlayerMiteData — ici on simule
        if (data.hasDisease(Disease.SCORBUT)) return; // déjà malade

        // La détection réelle se fait via un compteur dédié dans PlayerMiteData
        // (à ajouter comme champ si besoin d'une implémentation complète)
    }

    // ── Items de vitamine C ──────────────────────────────────────────

    /** Tags des aliments qui contiennent de la vitamine C (fruits, légumes). */
    public static boolean isVitaminFood(ItemStack stack) {
        var item = stack.getItem();
        return item == net.minecraft.item.Items.APPLE
            || item == net.minecraft.item.Items.GOLDEN_APPLE
            || item == net.minecraft.item.Items.ENCHANTED_GOLDEN_APPLE
            || item == net.minecraft.item.Items.MELON_SLICE
            || item == net.minecraft.item.Items.SWEET_BERRIES
            || item == net.minecraft.item.Items.GLOW_BERRIES
            || item == net.minecraft.item.Items.PUMPKIN_PIE;
    }
}
