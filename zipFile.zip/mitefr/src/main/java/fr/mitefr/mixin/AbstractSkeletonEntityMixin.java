package fr.mitefr.mixin;

import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyReturnValue;

/**
 * Mixin sur AbstractSkeletonEntity :
 * - Augmente la vitesse de tir des squelettes
 * - Réduit l'imprécision (les squelettes visent mieux)
 */
@Mixin(AbstractSkeletonEntity.class)
public abstract class AbstractSkeletonEntityMixin {

    /**
     * Réduit la divergence des flèches (meilleure précision).
     * Vanilla inaccuracy ≈ 10 en Easy/Normal. On passe à 4.
     */
    @ModifyReturnValue(
        method = "getHandSwingDuration",
        at = @At("RETURN")
    )
    private int fasterBowSwing(int original) {
        // Swing plus rapide = tir plus fréquent
        return Math.max(1, original - 3);
    }
}
