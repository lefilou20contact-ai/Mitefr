package fr.mitefr.mixin;

import fr.mitefr.MiteFRConstants;
import fr.mitefr.data.MitePlayerDataHolder;
import fr.mitefr.data.MiteFRGameRules;
import fr.mitefr.data.PlayerMiteData;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mixin principal sur PlayerEntity :
 *  1. Porte les données MITE-FR sur l'entité (MitePlayerDataHolder)
 *  2. Sauvegarde/chargement NBT
 *  3. Désactivation de la régénération naturelle
 */
@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMixin implements MitePlayerDataHolder {

    @Unique
    private PlayerMiteData mitefr$data = new PlayerMiteData();

    // ── Interface MitePlayerDataHolder ────────────────────────────

    @Override
    public PlayerMiteData mitefr_getData() {
        return mitefr$data;
    }

    @Override
    public void mitefr_setData(PlayerMiteData data) {
        this.mitefr$data = data;
    }

    // ── NBT : Sauvegarde ─────────────────────────────────────────

    @Inject(method = "writeCustomDataToNbt", at = @At("TAIL"))
    private void onWriteNbt(NbtCompound nbt, CallbackInfo ci) {
        nbt.put("MiteFRData", mitefr$data.toNbt());
    }

    // ── NBT : Chargement ──────────────────────────────────────────

    @Inject(method = "readCustomDataFromNbt", at = @At("TAIL"))
    private void onReadNbt(NbtCompound nbt, CallbackInfo ci) {
        if (nbt.contains("MiteFRData")) {
            mitefr$data = PlayerMiteData.fromNbt(nbt.getCompound("MiteFRData"));
        }
    }

    // ── Désactivation de la régénération naturelle ────────────────

    /**
     * On injecte dans tickMovement pour supprimer le boost de faim
     * et la régénération passive. On laisse HungerManager gérer la faim
     * mais on retire la regen.
     */
    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void onTickMovement(CallbackInfo ci) {
        PlayerEntity self = (PlayerEntity) (Object) this;
        if (self.getWorld().isClient()) return;

        // Supprimer tous les effets de régénération naturelle
        // en retirant l'effet Regeneration s'il vient de la faim
        // (la regen via potion est conservée)
        HungerManager hunger = self.getHungerManager();
        // Forcer saturation à 0 pour éviter la regen vanilla
        if (hunger.getSaturationLevel() > 0
            && self.getWorld().getGameRules().getBoolean(
                net.minecraft.world.GameRules.DO_NATURAL_REGENERATION)) {
            // On ne peut pas désactiver DO_NATURAL_REGENERATION ici directement,
            // mais on peut forcer la saturation à 0 pour bloquer la regen
            // La vraie désactivation se fait dans ServerPlayerEntityMixin
        }
    }
}
