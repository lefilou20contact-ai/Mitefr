package fr.mitefr.mixin;

import net.minecraft.entity.mob.MobEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyReturnValue;

/**
 * Mixin sur MobEntity :
 * - Double la portée de détection des mobs
 * - Empêche le despawn naturel
 */
@Mixin(MobEntity.class)
public abstract class MobEntityMixin {

    @ModifyReturnValue(method = "getFollowLeashSpeed", at = @At("RETURN"))
    private double modifyFollowSpeed(double original) {
        return original;
    }

    /**
     * Empêche le despawn naturel — comme dans MITE original.
     * Tous les mobs restent dans le monde indéfiniment.
     */
    @ModifyReturnValue(method = "canImmediatelyDespawn", at = @At("RETURN"))
    private boolean preventDespawn(boolean original) {
        return false;
    }

    /**
     * Double la portée de suivi du joueur.
     */
    @ModifyReturnValue(method = "getFollowRange", at = @At("RETURN"))
    private double doubleFollowRange(double original) {
        return original * 2.0;
    }
}
